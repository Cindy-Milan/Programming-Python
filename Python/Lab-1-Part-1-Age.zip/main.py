#Name: Cynthia Milan
#Course: Fall 2020, CSE 5208
#Lab 1 P.1
#Instructor: Prof. F. Muheidat
#9-8-2020
#NOTES: Extention to 9/11/2020 due to late enrollment

name = input("Hello, What is your name?: ")
age = int(input("Hello " + name + ", How old are you?: "))

year = 2020 - age
print(name, ", you were born in the year of ", year)