#Name: Cynthia Milan
#Course: Fall 2020, CSE 5208
#Lab 1 P.2
#Instructor: Prof. F. Muheidat
#9-8-2020
#NOTES: Extention to 9/11/2020 due to late enrollment

number = int(input("Hello, please enter a number: "))

print("The divisors are: ")

for i in range(1, number + 1):
  if number%i == 0:
    print(i)
  
  
