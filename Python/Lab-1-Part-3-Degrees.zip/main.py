#Name: Cynthia Milan
#Course: Fall 2020, CSE 5208
#Lab 1 P.3
#Instructor: Prof. F. Muheidat
#9-8-2020
#NOTES: Extention to 9/11/2020 due to late enrollment
import math

degree = int(input("Hello user, please enter a degree: "))
print()

#Checks the quadrant of the degree
if degree < 90:
  print("The degree is in the first quadrant.")
elif 90 < degree < 180:
  print("The degree is in the second quadrant.")
elif 180 < degree < 270:
  print("The degree is in the third quadrant.")
elif 270 < degree < 360:
  print("The degree is in the forth quadrant")
else:
  newdegree = degree%360

  if newdegree < 90:
    print("The degree is in the first quadrant.")
  if 90 < newdegree < 180:
    print("The degree is in the second quadrant.")
  if 180 < newdegree < 270:
    print("The degree is in the third quadrant.")
  if 270 < newdegree < 360:
    print("The degree is in the forth quadrant")
print()

#find degrees in radians
radians = math.radians(degree)
print("The degree in radians is ", radians)
print()

#find cosine, sine, tangent
cosine = math.cos(radians)
sine = math.sin(radians)
tan = math.tan(radians)

print("Sine is ", sine, ", cosine is ", cosine , ", and the tangent is ", tan)