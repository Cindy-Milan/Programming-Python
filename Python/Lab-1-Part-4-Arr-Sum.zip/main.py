#Name: Cynthia Milan
#Course: Fall 2020, CSE 5208
#Lab 1 P.4
#Instructor: Prof. F. Muheidat
#9-8-2020
#NOTES: Extention to 9/11/2020 due to late enrollment


def find_commulative_sum(arr):
  arr2 = []
  size = len(arr)
  arr2.append(arr[0])
  for i in range(1, size):
    sum1 = arr[i] + arr2[i-1]
    arr2.append(sum1)
    
  return arr2
    

arr = []
num = int(input("Please enter an amount of numbers: "))

for i in range(0, num):
  elnum = int(input())
  arr.append(elnum)

print("List of numbers inputed: ", arr)
print()
print("Sum of array elements are: ", find_commulative_sum(arr))

