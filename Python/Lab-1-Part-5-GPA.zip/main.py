#Name: Cynthia Milan
#Course: Fall 2020, CSE 5208
#Lab 1 P.5
#Instructor: Prof. F. Muheidat
#9-9-2020
#NOTES: Extention to 9/11/2020 due to late enrollment

import array
import string

#arrays for the list of informatiom based on course, score, and gpa
course = []
score1 = []
gradelist = []

# function that prints the gpa of the score received
def gpa(score):
  if 96<score<101:  #97 to 100
    gradegpa = (4.0) #A+    
  elif 92<score<97:  #93 to 96
    gradegpa = (4.0) #A
  elif 89<score<93:   #90 to 92
    gradegpa = (3.7) #A-
  elif 86<score<90: #87 to 89
    gradegpa = (3.3) #B+
  elif 82<score<87:  #83 to 86
    gradegpa = (3.0) #B
  elif 79<score<83:  #80 to 82
    gradegpa = (2.7) #B-
  elif 76<score<80:   #77 to 79
    gradegpa = (2.3) #C+
  elif 72<score<77: #73 to 76
    gradegpa = (2.0) #C
  elif 69<score<73: #70 to 72
    gradegpa = (1.7) #C-
  elif 66<score<70:  #67 to 69
    gradegpa = (1.3) #D+
  elif 62<score<67:  #63 to 66
    gradegpa = (1.0) #D
  elif 59<score<63:   #60 to 62
    gradegpa = (0.7) #D-
  elif score<60: # Below 60
    gradegpa = (0.0) #F
  return gradegpa

# function that calculates the overall gpa of the scores received
def gpaAll(gradelist):
  return sum(gradelist)/numcourses

# the beginning of the actual program, this asks for the student name and number of courses
student = input("Please enter student's name: ")
print()
numcourses = int(input("Please enter the amount of courses the student has: "))

# this for loop asks the user to input the course name and score, it also inputs them into an array
for i in range(0, numcourses):
  namecourse = input("Course?: ")
  course.append(namecourse)
  grade = int(input("Course Grade (0-100)?: "))
  score1.append(grade)

# this section calculated the gpa of the courses and the overall gpa and prints them along with the name of the student and courses
print()
print("Here is ", student, "'s Report Card:")
print("------------------------------------------------------------")
print("Course: Grade: Course GPA")
print("------------------------------------------------------------")
for i in range(0, numcourses):
  score = score1[i]
  print(course[i]," : ",score1[i]," : ",gpa(score))
  gradelist.append(gpa(score))

print()
print("Overall GPA: ", gpaAll(gradelist))