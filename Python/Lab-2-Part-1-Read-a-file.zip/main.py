#Name: Cynthia Milan
#Professor: Fadi Muheidat
#Course: CSE 5208
#Lab 2 P 1
#FALL 2020
#September 13, 2020

#needed for the csv file
import csv 

#searches for the file and reads it to print on the python IDE
with open('students.csv','r') as file:
  read = csv.reader(file)
  for line in read:
    print(line)