#Name: Cynthia Milan
#Professor: Fadi Muheidat
#Course: CSE 5208
#Lab 2 P 2
#FALL 2020
#September 13, 2020

from random import sample
import random

def typoglycemia(string):             #Function for typoglycemia
  n_word = ""                         #needed to keep the sentence going
  for word in string.split():         #every word in the sentence

    if len(word) <= 3:                #for words with 3 letters or less, print it as it is
      n_word = n_word + word + " "

    elif len(word) > 3:               #if the word has more than 3 letters, then shuffle the inbetween
      c_list = list(word[1:-1])       # it collects only the middle letters of the word without the first and las index
      random.shuffle(c_list)          #shuffles it
      final = ''.join(c_list)         #joins the characters

      final = list(final)             #recreates the list in order to add letters
      final.append(word[-1])          #adds the orinal ending element from the original word
      final.insert(0, word[0])        #inserts the original first element from the original word

      final = ''.join(final)          #joins them once again
      n_word = n_word + final + " "   #prints them properly
  return n_word                       #returns the sentence/string/word

file = open("scrambled.txt", "w")     #needed to open the result to this txt document
with open ('example.txt') as f:       #uses the material from this txt document to shuffle
  for line in f:
    n_line = typoglycemia(line)       #calls the function
    file.write(f"{n_line}\n")         #prints the material on the file

file.close()                          #closes the file once it is done shuffling


