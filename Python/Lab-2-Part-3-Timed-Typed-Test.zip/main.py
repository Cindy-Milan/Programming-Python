#Name: Cynthia Milan
#Instructor: Fadi Muheidat
#Course: CSE 5208
#Lab 2 Part 3
#FALL 2020
#September 14, 2020

#imports needed for shuffling and time
import random
import timeit
import time

#makes the strings and times into an array to calculate average
sentences=[]
time_taken=[]

# previosly written words are made into random sentences from the arrays
def random_sentence():
  adj = ("Smart", "Bright","Helpful","Intelligent","Sharp")
  nouns = ("students", "CSUSB", "professors", "CSE courses", "seniors")
  adverb = ("constantly","daily","weekly","yearly","nicely")
  verbs = ("study","research","code","motivate", "encourage")

  numbers = [0, 1, 2, 3, 4]
  x = random.choice(numbers)
  y = random.choice(numbers)
  z = random.choice(numbers)
  a = random.choice(numbers)

  string1 = adj[x]+" "+nouns[y]+" "+ adverb[z]+" "+verbs[a]
  final = ''.join(string1)
  return final

#writes the sentences and times with the average onto the times.txt file
def write_results(list_string, time_num):
  with open('times.txt','w+') as f:
    f.write("{}".format('Sentences\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tTime\n'+'---------\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-----\n'))
    total = 0
    avg = 0
    size = len(list_string)
    for i in range(size):
      num1 = time_num[i]
      f.write("{}".format(list_string[i]+'\n'+'\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t'+str(num1)+'\n'))
      total = total + time_num[i]
    avg = total/size
    f.write("{}".format('\nAverage time: '+'\t\t\t\t\t\t\t\t\t\t\t\t'+str(avg)+'\n'))
    f.close()

# increases the amount of times a sentence is randomly printed until it reaches 5 times
j = 0
while j < 5:
 
#starts timer as soon as the printed string is given, string is recorded onto array
  string2 = random_sentence()
  print(string2)
  sentences.append(string2)
  start = timeit.default_timer()
  string = input()

#stops and records the time typed after the user prints the string correctly, time is recorded onto array
  if string == string2:
    stop = timeit.default_timer()
    num_time = stop - start
    time_taken.append(num_time)
    print("Time: ", num_time)
    
#if they get it wrong, they repeat typing it until they get it right, after they do the timer stops and is recorded onto an array
  else:
    while string != string2:
      string = input()
    stop = timeit.default_timer()
    num_time = stop - start
    time_taken.append(num_time)
    print("Time: ", num_time)
    
  j +=1

#calls the write_results function for the text file
str(write_results(sentences, time_taken))
